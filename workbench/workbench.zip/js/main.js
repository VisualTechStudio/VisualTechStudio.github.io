// 修复页面切换逻辑，避免错位问题
function switchPage(page) {
    // 隐藏所有页面
    document.getElementById('home-page').style.display = 'none';
    document.getElementById('dashboard-page').style.display = 'none';
    
    // 移除菜单激活状态
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // 设置页面标题
    const pageTitleElement = document.getElementById('page-title');
    
    // 显示选中页面并设置菜单激活状态
    if (page === 'home') {
        document.getElementById('home-page').style.display = 'flex';
        document.querySelector('[data-page="home"]').classList.add('active');
        document.title = 'VTStudio Workbench |  首页';
        pageTitleElement.textContent = '|  首页';
    } else if (page === 'dashboard') {
        document.getElementById('dashboard-page').style.display = 'block';
        document.querySelector('[data-page="dashboard"]').classList.add('active');
        document.title = 'VTStudio Workbench |  仪表盘';
        pageTitleElement.textContent = '|  仪表盘';
        loadDashboardData();
    }
}

// 为菜单项添加点击事件监听器
document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', function() {
        const page = this.getAttribute('data-page');
        switchPage(page);
    });
});

document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const toggleIcon = document.querySelector('.toggle-icon i');
    const toggleText = document.querySelector('.toggle-text');

    sidebar.classList.toggle('collapsed');

    if (sidebar.classList.contains('collapsed')) {
        toggleIcon.className = 'fas fa-chevron-right';
        toggleText.textContent = '展开';
    } else {
        toggleIcon.className = 'fas fa-chevron-left';
        toggleText.textContent = '折叠';
    }
});

const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');

let currentTheme = localStorage.getItem('theme');
if (!currentTheme) {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)').matches;
    currentTheme = prefersDarkScheme ? 'dark' : 'light';
}

document.documentElement.setAttribute('data-theme', currentTheme);
updateThemeIcon(currentTheme);

function updateThemeIcon(theme) {
    if (theme === 'dark') {
        themeIcon.className = 'fas fa-sun';
    } else {
        themeIcon.className = 'fas fa-moon';
    }
}

themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
});

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
    if (!localStorage.getItem('theme')) {
        const newTheme = e.matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', newTheme);
        updateThemeIcon(newTheme);
    }
});

// Dashboard functionality
function loadDashboardData() {
    fetch('/api/system-info')
        .then(response => response.json())
        .then(data => {
            // 更新系统信息显示格式
            if (data.system) {
                document.getElementById('system-info').innerHTML = `
                    <strong>系统名称:</strong> ${data.system.name || 'N/A'}<br>
                    <strong>系统版本:</strong> ${data.system.version || 'N/A'}<br>
                    <strong>Linux内核:</strong> ${data.system.kernel || 'N/A'}<br>
                    <strong>运行时间:</strong> ${data.system.uptime || 'N/A'}
                `;
            } else {
                document.getElementById('system-info').textContent = '获取失败';
            }
            
            // 更新CPU信息显示格式
            if (data.cpu) {
                document.getElementById('cpu-info').innerHTML = `
                    <strong>CPU名称:</strong> ${data.cpu.model || 'N/A'}<br>
                    <strong>核心数:</strong> ${data.cpu.cores || 'N/A'}<br>
                    <strong>总占用:</strong> ${data.cpu.usage || 'N/A'}
                `;
            } else {
                document.getElementById('cpu-info').textContent = '获取失败';
            }
            
            // 更新内存信息显示格式
            if (data.memory) {
                document.getElementById('memory-info').innerHTML = `
                    <strong>已使用/总大小:</strong> ${data.memory.used}/${data.memory.total}<br>
                    <strong>使用率:</strong> ${data.memory.percent || 'N/A'}
                `;
            } else {
                document.getElementById('memory-info').textContent = '获取失败';
            }
            
            // 更新磁盘信息显示格式
            if (data.disks && data.disks.length > 0) {
                let diskInfo = '';
                data.disks.forEach(disk => {
                    diskInfo += `<strong>设备 ${disk.device}:</strong> ${disk.used}/${disk.total} (${disk.percent})<br>`;
                });
                document.getElementById('disk-info').innerHTML = diskInfo;
            } else {
                document.getElementById('disk-info').textContent = '获取失败';
            }
        })
        .catch(error => {
            console.error('获取系统信息失败:', error);
            document.getElementById('system-info').textContent = '获取失败: ' + error.message;
            document.getElementById('cpu-info').textContent = '获取失败: ' + error.message;
            document.getElementById('memory-info').textContent = '获取失败: ' + error.message;
            document.getElementById('disk-info').textContent = '获取失败: ' + error.message;
        });
}

document.getElementById('refresh-dashboard').addEventListener('click', loadDashboardData);

// 初始化默认显示首页
switchPage('home');